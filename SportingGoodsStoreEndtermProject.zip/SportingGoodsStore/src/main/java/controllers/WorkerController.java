package controllers;

import entities.Worker;
import filters.customAnnotations.JWTTokenNeeded;
import services.interfaces.IWorkerService;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@JWTTokenNeeded
@Path("workers")
public class WorkerController {
    @Inject
    private IWorkerService workerService;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllWorkers() {
        List<Worker> workers;
        try {
            workers = workerService.getAll();
        } catch (ServerErrorException ex) {
            return Response
                    .status(500).entity(ex.getMessage()).build();
        }

        return Response
                .ok(workers)
                .build();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createWorker(Worker worker) {
        boolean created;
        try {
            created = workerService.create(worker);
        } catch (ServerErrorException ex) {
            return Response.serverError().entity(ex.getMessage()).build();
        }

        if (!created) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity("Worker account cannot be created!")
                    .build();
        }

        return Response
                .status(Response.Status.CREATED)
                .entity("Worker account created successfully!")
                .build();
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getWorker(@PathParam("id") int id) {
        Worker worker;
        try {
            worker = workerService.get(id);
        } catch (ServerErrorException ex) {
            return Response
                    .status(500).entity(ex.getMessage()).build();
        }

        if (worker == null) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Worker account does not exist!")
                    .build();
        }

        return Response
                .status(Response.Status.OK)
                .entity(worker)
                .build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteWorker(@PathParam("id") int id) {
        boolean removed;

        try {
            removed = workerService.delete(id);
        } catch (ServerErrorException ex) {
            return Response
                    .status(500).entity(ex.getMessage()).build();
        }

        if (removed) {
            return Response.ok("A worker account was removed successfully!").build();
        } else {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity("A worker account with such id was not found!")
                    .build();
        }
    }
}
