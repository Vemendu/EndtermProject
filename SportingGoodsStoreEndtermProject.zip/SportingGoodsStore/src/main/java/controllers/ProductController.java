package controllers;

import entities.Product;
import entities.User;
import filters.customAnnotations.JWTTokenNeeded;
import services.interfaces.IProductService;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("products")
public class ProductController {
    @Inject
    private IProductService productService;

    @JWTTokenNeeded
    @GET
    public Response getAllProducts() {
        List<Product> products;
        try {
            products = productService.getAll();
        } catch (ServerErrorException ex) {
            return Response
                    .status(500).entity(ex.getMessage()).build();
        }

        return Response
                .ok(products)
                .build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteProduct(@PathParam("id") int id) {
        boolean removed;

        try {
            removed = productService.delete(id);
        } catch (ServerErrorException ex) {
            return Response
                    .status(500).entity(ex.getMessage()).build();
        }

        if (removed) {
            return Response.ok("A product was removed successfully!").build();
        } else {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity("A product with such id was not found!")
                    .build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createProduct(Product product) {
        boolean created;
        try {
            created = productService.create(product);
        } catch (ServerErrorException ex) {
            return Response.serverError().entity(ex.getMessage()).build();
        }

        if (!created) {
            return Response
                    .status(Response.Status.BAD_REQUEST)
                    .entity("Product cannot be created!")
                    .build();
        }

        return Response
                .status(Response.Status.CREATED)
                .entity("Product created successfully!")
                .build();
    }

    @JWTTokenNeeded
    @GET
    @Path("/{id}")
    public Response getProductById(@PathParam("id") int id) {
        Product product;
        try {
            product = productService.getProductById(id);
        } catch (ServerErrorException ex) {
            return Response
                    .status(500).entity(ex.getMessage()).build();
        }

        if (product == null) {
            return Response
                    .status(Response.Status.NOT_FOUND)
                    .entity("Product does not exist!")
                    .build();
        }

        return Response
                .status(Response.Status.OK)
                .entity(product)
                .build();
    }
}
