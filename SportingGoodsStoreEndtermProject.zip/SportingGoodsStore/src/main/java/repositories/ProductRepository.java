package repositories;

import data.interfaces.IDB;
import entities.Category;
import entities.Product;
import entities.User;
import repositories.interfaces.IProductRepository;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import javax.inject.Inject;
import java.sql.*;
import java.util.LinkedList;
import java.util.List;

public class ProductRepository implements IProductRepository {
    @Inject
    private IDB db;

    @Override
    public boolean create(Product product) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "INSERT INTO products(id,name,description,price,category_id,stockAmount) VALUES (?,?,?,?,?,?)";
            PreparedStatement st = con.prepareStatement(sql);


            st.setInt(1, product.getId());
            st.setString(2, product.getName());
            st.setString(3, product.getDescription());
            st.setDouble(4, product.getPrice());
            st.setInt(5, product.getCategoryId());
            st.setInt(6, product.getStockAmount());


            st.execute();
            return true;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public Product get(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT id,name,description,price,category_id,stockAmount from products where id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                Product product = new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("category_id"),
                        rs.getInt("stockAmount")
                );

                return product;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public List<Product> getAll() {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT id,name,description,price,category_id,stockAmount FROM products";
            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);
            List<Product> products = new LinkedList<>();
            while (rs.next()) {
                Product product = new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("category_id"),
                        rs.getInt("stockAmount"));

                products.add(product);
            }

            return products;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public boolean delete(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "DELETE FROM products WHERE id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);

            st.execute();

            return st.getUpdateCount() > 0;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }

        return false;
    }
}
