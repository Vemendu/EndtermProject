package repositories.interfaces;

import entities.Product;
import repositories.interfaces.base.IRepository;


public interface IProductRepository extends IRepository<Product> {

}