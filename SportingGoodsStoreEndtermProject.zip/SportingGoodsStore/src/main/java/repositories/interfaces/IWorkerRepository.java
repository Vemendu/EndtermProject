package repositories.interfaces;

import entities.Worker;
import repositories.interfaces.base.IRepository;

public interface IWorkerRepository extends IRepository<Worker> {
}
