package services.interfaces;

import entities.Worker;

import java.util.List;

public interface IWorkerService {
    List<Worker> getAll();

    boolean create(Worker worker);

    Worker get(int id);

    boolean delete(int id);
}
