package services.interfaces;

import entities.Product;
import entities.User;

import java.util.List;

public interface IProductService {
    List<Product> getAll();

    boolean create(Product product);

    Product get(int id);

    boolean delete(int id);

    Product getProductById(int id);
}