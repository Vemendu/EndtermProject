package services;

import entities.Worker;
import repositories.interfaces.IWorkerRepository;
import services.interfaces.IWorkerService;

import javax.inject.Inject;
import java.util.List;

public class WorkerService implements IWorkerService{

    @Inject
    private IWorkerRepository workerRepository;

    @Override
    public List<Worker> getAll() {
        List<Worker> workers = workerRepository.getAll();
        return workers;
    }

    @Override
    public boolean create(Worker worker) {
        return workerRepository.create(worker);
    }

    @Override
    public Worker get(int id) {
        return workerRepository.get(id);
    }

    @Override
    public boolean delete(int id) {
        return workerRepository.delete(id);
    }
}
