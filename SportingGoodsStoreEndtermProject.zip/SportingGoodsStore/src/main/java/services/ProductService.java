package services;

import entities.Product;
import entities.User;
import repositories.interfaces.IProductRepository;
import services.interfaces.IProductService;

import javax.inject.Inject;
import java.util.List;

public class ProductService implements IProductService {
    @Inject
    private IProductRepository productRepository;

    @Override
    public List<Product> getAll() {
        List<Product> products = productRepository.getAll();
        return products;
    }

    @Override
    public Product getProductById(int id) {
        return productRepository.get(id);
    }
    @Override
    public boolean create(Product product) {
        return productRepository.create(product);
    }

    @Override
    public Product get(int id) {
        return productRepository.get(id);
    }

    @Override
    public boolean delete(int id) {
        return productRepository.delete(id);
    }
}